<table id="userTable" class="display" style="width:100%">
    <thead>
        <tr>
            <th>Nama</th>
            <th>Jenis Kelamin</th>
            <th>Hobi</th>
            <th>Email</th>
            <th>Telefon</th>
            <th>Username</th>
            <th>Password</th>
            <th>Edit</th>
        </tr>
    </thead>
    <tbody>
        @foreach($datas as $data)
        <tr>
            <td>{{$data->nama}}</td>
            <td>{{$data->jenis_kelamin}}</td>
            <td>{{$data->hobi}}</td>
            <td>{{$data->email}}</td>
            <td>{{$data->telp}}</td>
            <td>{{$data->username}}</td>
            <td>{{$data->password}}</td>
            <td><form action="/user/{{$data->id}}" method="post"> @csrf @method('DELETE') <button>Hapus</button> </form></td>
        </tr>
        @endforeach
    </tbody>
</table>

<script>
    $(document).ready( function () {
        $('#userTable').DataTable();
    } );
</script>