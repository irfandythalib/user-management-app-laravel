-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 07, 2022 at 10:30 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eyden`
--

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `jenis_kelamin` varchar(20) NOT NULL,
  `hobi` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `telp` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `nama`, `jenis_kelamin`, `hobi`, `email`, `telp`, `username`, `password`, `created_at`, `updated_at`) VALUES
(4, 'Irfandy T', 'Pria', 'Membaca', 'irfandythalib@gmail.com', '285222201191', 'asdsda', 'sadsadasd', '2022-08-06 05:08:13', '2022-08-06 05:08:13'),
(6, 'Bambang', 'Pria', 'Membaca', 'irfandythalib@gmail.com', '085222201191', 'bambang', '1234567', '2022-08-06 17:35:30', '2022-08-06 17:35:30'),
(7, 'Zulfikar Thalib', 'Pria', 'Membaca|Travelling', 'irfandythalib@gmail.com', '085222201191', 'zulfikar', '12345678', '2022-08-06 20:53:35', '2022-08-06 20:53:35'),
(10, 'Irfandy T', 'Wanita', 'Membaca|Travelling', 'irfandythalib@gmail.com', '85222201191', 'irfandyth', 'dqewfwdasfdfsf', '2022-08-06 22:56:26', '2022-08-06 22:56:26'),
(11, 'Irfandy T', 'Pria', 'Travelling', 'irfandythalib@gmail.com', '+6285222201191', 'gimba', '765676545', '2022-08-06 22:56:43', '2022-08-06 22:56:43'),
(13, 'Irfandy T', 'Wanita', 'Membaca|Travelling', 'irfandythalib@gmail.com', '85222201191', 'irfandyts', '13245344235', '2022-08-06 23:01:31', '2022-08-06 23:01:31'),
(14, 'Irfandy T', 'Pria', 'Membaca', 'irfandythalib@gmail.com', '5222201191', 'fandyt', '12342434', '2022-08-06 23:10:48', '2022-08-06 23:10:48'),
(15, 'Irfandy Thalib', 'Pria', 'Membaca|Travelling', 'rudi@gmail.com', '085222201191', 'imran', '65432343', '2022-08-06 23:22:41', '2022-08-06 23:22:41'),
(16, 'Irfandy T', 'Pria', 'Travelling', 'irfandythalib@gmail.com', '2201191', 'fandyt', '113234223', '2022-08-06 23:33:21', '2022-08-06 23:33:21'),
(17, 'Irfandy Thalib', 'Pria', 'Membaca', 'fandy@gmail.com', '123456789', 'fandyxx', '12345678', '2022-08-07 00:23:44', '2022-08-07 00:23:44');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
