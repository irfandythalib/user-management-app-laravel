
<?php $__env->startSection('content'); ?>
<h2 class="text-center"><b>User</b></h2>
<!--Error Handler-->
<?php if($errors->any()): ?> 
    <?php $al = '';?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $al .= $error.' || ';?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <script>alert("<?=$al?>");</script>
<?php endif; ?>

<?php if(session()->has('message')): ?>
    <script>alert("<?php echo e(session()->get('message')); ?>");</script>
<?php endif; ?>

<div class="container bg-light bg-gradient px-5 py-4 mb-5">
<h4><b>Input Data Baru</b></h4>
<form action='/user' method='post' id='regform'>
  <div class="row">
    <div class="col">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for=""><b>Name</b></label>
            <input type="text" class="form-control" name="name" placeholder="Enter your name"  value='<?php echo e(old("name")); ?>'>
            <small class="form-text text-muted">Capital First Letter</small>
        </div>
        <div class="form-group mt-2">
            <label><b>Jenis Kelamin</b></label>
            <div class="row">
                <div class="col">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="jenis_kelamin" id="" value="Pria">
                        <label class="form-check-label" for="exampleRadios1">
                            Pria
                        </label>
                    </div>
                </div>
                <div class="col">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="jenis_kelamin" id="" value="Wanita">
                        <label class="form-check-label" for="exampleRadios2">
                            Wanita
                        </label>
                    </div>
                </div>
            </div>
        </div>
        <div class="form-group mt-2 mb-2">
            <label><b>Hobi</b></label>
            <div class="row">
                <div class="col">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="hobi[]" value="Membaca" id="">
                        <label class="form-check-label" for="">
                            Membaca
                        </label>
                    </div>
                </div>
                <div class="col">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="hobi[]" value="Travelling" id="">
                        <label class="form-check-label" for="">
                            Travelling
                        </label>
                    </div>
                </div>
            </div>
        </div>
        <div class="form-group">
            <label for=""><b>Email</b></label>
            <input type="text" class="form-control" name="email" placeholder="Enter your name"  value='<?php echo e(old("email")); ?>'>
        </div>
    </div>
    <div class="col">
        <div class="form-group">
            <label for=""><b>No Telefon</b></label>
            <input type="text" class="form-control" name="phone" placeholder="Enter your Phone"  value='<?php echo e(old("phone")); ?>'>
            <small class="form-text text-muted">Numeric only</small>
        </div>
        <div class="form-group">
            <label for=""><b>Username</b></label>
            <input type="text" class="form-control" name="username" placeholder="Enter your Username"  value='<?php echo e(old("username")); ?>'>
            <small class="form-text text-muted">Max. 10 characters</small>
        </div>
        <div class="form-group">
            <label for=""><b>Password</b></label>
            <input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Password"  value='<?php echo e(old("password")); ?>'>
            <small class="form-text text-muted">Min. 7 characters</small>
        </div>
        <div class="form-group pt-2">
            <button type="submit" id="submit" class="btn btn-primary">Submit</button>
            <button type="button" onclick="reset()" id="submit" class="btn btn-warning">Reset Form</button>    
        </div>
        </div>
  </div>
  </form>
</div>
<hr>
<div class='container bg-light bg-gradient  px-4 py-4'>
<h4><b>Filter Data</b></h4>
    <div class='row'>
        <div class='col'>
            <div class="form-group">
                <label for="">Jenis Kelamin</label>
                <select class="form-control filters" id="filterJenisKelamin">
                    <option value="-">--Pilih Data--</option>
                    <option value="Pria">Pria</option>
                    <option value="Wanita">Wanita</option>
                </select>
            </div>
        </div>
        <div class='col'>
            <div class="form-group">
                <label for="">Hobi</label>
                <select class="form-control filters" id="filterHobi">
                    <option value="-">--Pilih Data--</option>
                    <option value="Membaca">Membaca</option>
                    <option value="Travelling">Travelling</option>
                </select>
            </div>
        </div>
    </div>
</div>
<hr>
    
<div class='container'>
    <div class="row" id="datas">
        <div class="col-md-12">
            <table id="userTable" class="display" style="width:100%">
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>Jenis Kelamin</th>
                        <th>Hobi</th>
                        <th>Email</th>
                        <th>Telefon</th>
                        <th>Username</th>
                        <th>Password</th>
                        <th>Edit</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($data->nama); ?></td>
                        <td><?php echo e($data->jenis_kelamin); ?></td>
                        <td><?php echo e($data->hobi); ?></td>
                        <td><?php echo e($data->email); ?></td>
                        <td><?php echo e($data->telp); ?></td>
                        <td><?php echo e($data->username); ?></td>
                        <td><?php echo e($data->password); ?></td>
                        <td><form action="/user/<?php echo e($data->id); ?>" method="post"> <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?> <button>Hapus</button> </form></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<hr class="mb-3">


<script>
    $(document).ready( function () {
        $('#userTable').DataTable();
    } );

    $('.filters').change(function(){
        filterJenisKelamin = $('#filterJenisKelamin').val();
        filterHobi = $('#filterHobi').val();
        $.ajax({
            url: '/user',
            type: 'GET',
            data: { filterJenisKelamin,filterHobi},
            success: function(response)
            {
                $( '#datas' ).html( response );
            }
        });
    })
</script>
<script>
    function reset() {
    document.getElementById("regform").reset();
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\eyden\resources\views/frontapp/user.blade.php ENDPATH**/ ?>