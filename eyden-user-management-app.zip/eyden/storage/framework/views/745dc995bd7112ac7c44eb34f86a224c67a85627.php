<table id="userTable" class="display" style="width:100%">
    <thead>
        <tr>
            <th>Nama</th>
            <th>Jenis Kelamin</th>
            <th>Hobi</th>
            <th>Email</th>
            <th>Telefon</th>
            <th>Username</th>
            <th>Password</th>
            <th>Edit</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($data->nama); ?></td>
            <td><?php echo e($data->jenis_kelamin); ?></td>
            <td><?php echo e($data->hobi); ?></td>
            <td><?php echo e($data->email); ?></td>
            <td><?php echo e($data->telp); ?></td>
            <td><?php echo e($data->username); ?></td>
            <td><?php echo e($data->password); ?></td>
            <td><form action="/user/<?php echo e($data->id); ?>" method="post"> <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?> <button>Hapus</button> </form></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<script>
    $(document).ready( function () {
        $('#userTable').DataTable();
    } );
</script><?php /**PATH C:\xampp\htdocs\eyden\resources\views/frontapp/usertablefilter.blade.php ENDPATH**/ ?>