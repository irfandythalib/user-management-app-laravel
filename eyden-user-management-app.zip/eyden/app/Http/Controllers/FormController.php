<?php

namespace App\Http\Controllers;

use App\Models\Users;
use App\Rules\CapitalLetterCheck;
use Illuminate\Http\Request;

class FormController extends Controller
{
    /**
     * Display a listing of the resource.
     * Author: Irfandy Thalib
     *
     * @return \Illuminate\Http\Response
     */

    public function indexx(Request $request)
    {
        
        return $request->filterHobi;
    }
    public function index(Request $request)
    {
        /**
         * Kondisi jika filter terisi, maka data akan diambil
         * berdasarkan filter yang ada
         * irfandythalib@gmail.com
         * Created at: 07/08/2022
         */
        if(isset($request->filterHobi)){
            $data = Users::select('*')
                ->where('hobi', 'LIKE', '%'.$request->filterHobi.'%')
                ->where('jenis_kelamin', '=', $request->filterJenisKelamin)
                ->get();
            if($request->filterHobi == '-'){
                $data = Users::select('*')
                ->where('jenis_kelamin', '=', $request->filterJenisKelamin)
                ->get();
            }
            if($request->filterJenisKelamin == '-'){
                $data = Users::select('*')
                ->where('hobi', 'LIKE', '%'.$request->filterHobi.'%')
                ->get();
            }
            return view('frontapp.usertablefilter',
                ['datas' => $data]
            );
        }
        /**
         * Kondisi jika filter tidak terisi, maka 
         * semua data di tabel database akan diambil
         */
        else{
            $data = Users::all();
            
            return view('frontapp.user',
                ['datas' => $data]
            );
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        /**
         * Validasi untuk form input sesuai requirement
         * irfandythalib@gmail.com
         * Created at: 07/08/2022
         */
        $request->validate([
            'name' => [ 'required', new CapitalLetterCheck() ], //*Huruf depan harus kapital */
            'jenis_kelamin' => 'required',
            'hobi' => 'required',
            'email' => 'required|email', /* Format email harus benar */
            'phone' => 'required|numeric', /*Hanya bisa menerima angka*/
            'username' => 'required|max:10', /*Maksimal 10 karakter*/
            'password' => 'required|min:7', /* Minimal 7 karakter */
        ]);
        $users = new Users;
        $users->nama = $request->name;
        $users->jenis_kelamin = $request->jenis_kelamin;
        $users->hobi = implode("|",$request->hobi) ;
        $users->email = $request->email;
        $users->telp = $request->phone;
        $users->username = $request->username;
        $users->password = $request->password;
        $users->save();

        $request->session()->flash('alert-success', 'User was successful added!');
        return redirect('/user')->with('message', 'Data Has Been Saved');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Users::find($id)->delete();        
        return redirect('/user')->with('message', 'Data Has Been Deleted');
    }
}
