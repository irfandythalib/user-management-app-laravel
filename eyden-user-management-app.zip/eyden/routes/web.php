<?php

use Illuminate\Support\Facades\Route;
// use App\Http\Controllers\FormController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

/**
 * Router yang dipakai untuk User Management
 * Author: Irfandy Thalib
 * irfandythalib@gmail.com
 * Created at: 07/08/2022
 */
Route::get('user', 'App\Http\Controllers\FormController@index');
Route::post('user', 'App\Http\Controllers\FormController@store');
Route::delete('user/{id}', 'App\Http\Controllers\FormController@destroy');


